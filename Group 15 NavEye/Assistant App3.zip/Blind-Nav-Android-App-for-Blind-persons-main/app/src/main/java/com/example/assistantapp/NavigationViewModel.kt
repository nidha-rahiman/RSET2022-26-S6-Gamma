package com.example.assistantapp
import com.google.android.gms.maps.model.LatLng
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class NavigationViewModel : ViewModel() {
    private val _routeState = MutableStateFlow<RouteState>(RouteState.Idle)
    val routeState: StateFlow<RouteState> = _routeState

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.openrouteservice.org/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val service = retrofit.create(RouteService::class.java)

    fun fetchRoute(start: String, end: String) {
        viewModelScope.launch {
            _routeState.value = RouteState.Loading
            try {
                val response = service.getRoute(
                    apiKey = "5b3ce3597851110001cf624828f799c4e10a4908b87c9d480519a4b2", // Replace with your actual API key
                    start = start,
                    end = end
                ).execute()

                if (response.isSuccessful) {
                    response.body()?.let { routeResponse ->
                        val decodedPath = PolylineDecoder.decode(routeResponse.routes[0].geometry)
                        _routeState.value = RouteState.Success(
                            distance = routeResponse.routes[0].summary.distance,
                            duration = routeResponse.routes[0].summary.duration,
                            path = decodedPath
                        )
                    } ?: run {
                        _routeState.value = RouteState.Error("Empty response")
                    }
                } else {
                    _routeState.value = RouteState.Error(response.message())
                }
            } catch (e: Exception) {
                _routeState.value = RouteState.Error(e.message ?: "Unknown error")
            }
        }
    }
}

sealed class RouteState {
    object Idle : RouteState()
    object Loading : RouteState()
    data class Success(
        val distance: Int,
        val duration: Int,
        val path: List<LatLng>
    ) : RouteState()
    data class Error(val message: String) : RouteState()
}