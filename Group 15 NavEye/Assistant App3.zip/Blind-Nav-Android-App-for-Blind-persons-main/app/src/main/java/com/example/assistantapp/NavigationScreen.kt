package com.example.assistantapp

// NavigationScreen.kt


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.maps.model.LatLng

@Composable
fun NavigationScreen(
    start: String = "8.681495,49.41461", // Default values
    end: String = "8.687872,49.420318"
) {
    val viewModel: NavigationViewModel = viewModel()
    val routeState by viewModel.routeState.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.fetchRoute(start, end)
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        when (val state = routeState) {
            is RouteState.Idle -> {
                Text("Ready to navigate")
            }
            is RouteState.Loading -> {
                CircularProgressIndicator()
            }
            is RouteState.Success -> {
                Text("Distance: ${state.distance} meters")
                Spacer(modifier = Modifier.height(8.dp))
                Text("Duration: ${state.duration / 60} minutes")
                // Here you would display your map with the path
                // You'll need to implement a Map composable
            }
            is RouteState.Error -> {
                Text("Error: ${state.message}", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}