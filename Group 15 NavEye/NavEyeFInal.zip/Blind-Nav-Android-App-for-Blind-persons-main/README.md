 Nav-Eye---Android-App-for-Visually-Challenged

 
  ### ⭕ NavEye is an Android Application which helps the Blind people to navigate their surroundings and Environment just with the help of their Mobile Phones Camera and the Internet.

  #### LETS START

# Features:

This app has the 4 main features.

1️⃣ **Object Detection Mode**: when the app is opened and the new session has been created, once the user says detect object the app describes the surroundings and nearby obstacles .

2️⃣ **Assistant Mode**: By double tapping in the Object detection Mode the Assistant Mode will be activated and the purpose of the Assistant Mode is that user can ask any question about the 
 current environment ,for example: what is the color of the car,  Color of the bottle, how is the weather and any specific thing. users can also ask about any other things like who is Elon Musk.

3️⃣ **Reading Mode** : Reading mode is a mode which will help the user in reading sign-boards or books etc. It's basic feature is to read the text on anything.This mode will be activated when the user long taps in the object detection mode.

4️⃣ **Outdoor Navigation** : When the user says "Navigate Me" the app provides directions from the current location to the destination as mentioned by the user.


# LICENSE

MIT License

Copyright (c) 2025 Nandana Anukumar, Nikhitha Konnikkara Chandran, Rinu Tony, Vignesh P Ram

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE

