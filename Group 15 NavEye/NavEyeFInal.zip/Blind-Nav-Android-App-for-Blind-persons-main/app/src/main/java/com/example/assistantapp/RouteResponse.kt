package com.example.assistantapp

data class RouteResponse(
    val routes: List<Route>
)

data class Route(
    val summary: RouteSummary,
    val geometry: String // This is typically the polyline or geometry data
)

data class RouteSummary(
    val distance: Int, // Distance in meters
    val duration: Int  // Duration in seconds
)
