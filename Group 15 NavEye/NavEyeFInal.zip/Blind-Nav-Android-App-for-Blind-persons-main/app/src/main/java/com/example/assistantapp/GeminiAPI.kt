package com.example.assistantapp

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.BlockThreshold
import com.google.ai.client.generativeai.type.HarmCategory
import com.google.ai.client.generativeai.type.SafetySetting
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

val generativeModel = GenerativeModel(
    modelName = "gemini-1.5-flash",
    apiKey = "AIzaSyAHGQMhEicLpj1eE55UBh1G1HXac_p6afg",
    generationConfig = generationConfig {
        temperature = 1f
        topK = 64
        topP = 0.95f
        maxOutputTokens = 8192
        responseMimeType = "text/plain"
    },
    safetySettings = listOf(
        SafetySetting(HarmCategory.HARASSMENT, BlockThreshold.NONE),
        SafetySetting(HarmCategory.HATE_SPEECH, BlockThreshold.NONE),
        SafetySetting(HarmCategory.SEXUALLY_EXPLICIT, BlockThreshold.NONE),
        SafetySetting(HarmCategory.DANGEROUS_CONTENT, BlockThreshold.NONE)
    ),
    systemInstruction = content {
        text(
            """
            Purpose:
            You're an advanced navigation assistant designed to help visually impaired individuals navigate various environments safely and efficiently. 
            Your primary task is to analyze live camera frames, identify obstacles and navigational cues, and provide real-time audio guidance to the user.
            
            Your prompt on one frame should not contain more than 3 to 4 sentences.

            Main Considerations:
            - Identify objects in frames and describe them (e.g., car color, bottle color, shirt size, terrain roughness, etc.).
            - Provide clear, concise, and actionable navigation instructions.
            - Avoid technical jargon (e.g., don’t mention "image quality issues").
            - Analyze frames collectively and provide responses every 4 seconds to avoid repetition.

            Environment-Specific Guidelines:
            - **Urban (Cities, Highways, Roads)**: Identify stairs, curbs, obstacles, crosswalks, sidewalks, and traffic.
            - **Natural (Jungles, Villages, Grounds)**: Identify trees, water bodies, terrain variations, trails, and landmarks.
            - **Public Transport (Buses, Trains, Stations)**: Identify platform edges, doors, handrails, and seating.
            - **Indoor (Offices, Homes)**: Guide through furniture, doors, stairs, rooms, and objects/appliances.

            Final Notes:
            - Keep responses **brief and action-oriented** (e.g., "There is a car 5 steps ahead, stop or turn.").
            - Provide **real-time updates** and ensure user safety.
            """
        )
    }
)

suspend fun sendFrameToGeminiAI(
    bitmap: Bitmap,
    onPartialResult: (String) -> Unit,
    onError: (String) -> Unit
) {
    try {
        withContext(Dispatchers.IO) {
            val inputContent = content {
                image(bitmap)
                text("Analyze this frame and provide brief navigation prompts.")
            }

            var fullResponse = ""
            generativeModel.generateContentStream(inputContent).collect { chunk ->
                chunk.text?.let {
                    fullResponse += it
                    onPartialResult(it)
                }
            }
        }
    } catch (e: IOException) {
        Log.e("GeminiAI", "Network error: ${e.message}")
        onError("Network error: ${e.message}")
    } catch (e: Exception) {
        Log.e("GeminiAI", "Unexpected error: ${e.message}")
        onError("Unexpected error: ${e.message}")
    }
}

fun ImageProxy.toBitmap(): Bitmap? {
    return try {
        val buffer = this.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    } catch (e: Exception) {
        Log.e("ImageProxy", "Error converting ImageProxy to Bitmap: ${e.message}")
        null
    }
}
