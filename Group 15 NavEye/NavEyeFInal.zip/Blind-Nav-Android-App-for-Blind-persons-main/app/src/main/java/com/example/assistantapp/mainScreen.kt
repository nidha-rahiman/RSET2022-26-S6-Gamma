package com.example.assistantapp

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import java.util.Locale

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MainPage(navController: NavHostController) {
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    var isSettingsVisible by remember { mutableStateOf(false) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }

    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    matches?.let {
                        for (result in it) {
                            when (result.lowercase()) {
                                "detect object" -> navController.navigate("blindMode")
                                "navigate me" -> navController.navigate("outdoorNavigation")
                            }
                        }
                    }
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        speechRecognizer = recognizer

        onDispose {
            tts?.stop()
            tts?.shutdown()
            recognizer.destroy()
        }
    }

    LaunchedEffect(Unit) {
        speechRecognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        })
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "NavEye",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF1E1E2E)
                )
            )
        }
    ) { paddingValues ->
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF1E1E2E))
                .padding(paddingValues)
        ) {
            val cardOffset by animateDpAsState(
                targetValue = if (isSettingsVisible) (-240).dp else 0.dp,
                animationSpec = tween(300)
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                NavigationCard("Outdoor Navigation", Color(0xFF4CAF50), cardOffset) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    navController.navigate("outdoorNavigation")
                }
                NavigationCard("Detect Object", Color(0xFFB0B1B1), cardOffset) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    navController.navigate("blindMode")
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 20.dp)
            ) {
                SettingsButton(isSettingsVisible) {
                    isSettingsVisible = !isSettingsVisible
                    if (isSettingsVisible) {
                        tts?.speak(
                            "Here are the instructions Say detect object to detect the things around you also long tap to enter reading mode to read any text and double tap to enter assistant mode." +
                                    "Say navigate me to get the outdoor directions Happy Exploring." +
                                    "This app was created by Nikhitha Konnikkara Chandran, Rinu Tony, Nandana Anukumar and Vignesh P Ram as a part of our S6 mini project. ",
                            TextToSpeech.QUEUE_FLUSH, null, null
                        )
                    } else {
                        tts?.stop()
                    }
                }

                AnimatedVisibility(visible = isSettingsVisible) {
                    InstructionsPanel(context)
                }
            }
        }
    }
}

@Composable
fun NavigationCard(
    title: String,
    color: Color,
    offset: Dp,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        modifier = Modifier
            .offset(y = offset)
            .fillMaxWidth(0.8f)
            .height(120.dp)
            .padding(8.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        shape = RoundedCornerShape(20.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun SettingsButton(isExpanded: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(Color(0xFF37474F))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = "Settings",
            tint = Color.White
        )
    }
}

@Composable
fun InstructionsPanel(context: android.content.Context) {
    val annotatedText = buildAnnotatedString {
        append("🔷 To Master the navigation through this App, follow these instructions below:👇\n")
        append("1️⃣ Say *detect object* to detect the things around you..also long tap to enter reading mode to read any text and double tap to enter assistant mode.\n")
        append("2️⃣ Say *navigate me* to get the outdoor directions. \n")
        append("🔷 Happy Exploring !!😎 \n")
        append("🔷This app was created by Nikhitha Konnikkara Chandran, Rinu Tony, Nandana Anukumar and Vignesh P Ram as a part of our S6 mini project.\n ")
       // pushStringAnnotation("URL", "https://www.youtube.com/watch?v=GD4iuPCIXTc")
        //withStyle(
          //  SpanStyle(color = Color.Blue, textDecoration = TextDecoration.Underline)
       // ) { append("YouTube Video") }
       // pop()
       // append(" for details.")
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF2C2F33), shape = RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        item {
            ClickableText(
                text = annotatedText,
                onClick = { offset ->
                    annotatedText.getStringAnnotations("URL", offset, offset)
                        .firstOrNull()?.let { annotation ->
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(annotation.item)))
                        }
                },
                style = androidx.compose.ui.text.TextStyle(fontSize = 18.sp, color = Color.White)
            )
        }
    }
}