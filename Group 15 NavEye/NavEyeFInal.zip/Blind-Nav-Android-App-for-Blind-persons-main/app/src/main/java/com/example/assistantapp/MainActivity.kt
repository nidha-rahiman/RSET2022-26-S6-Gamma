package com.example.assistantapp

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import kotlinx.coroutines.delay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.ui.semantics.contentDescription
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.location.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.*

class MainActivity : ComponentActivity() {
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.all { it.value }
        if (!allGranted) {
            Toast.makeText(this, "Some required permissions were not granted", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // All permissions needed for both outdoor navigation and blind mode
        val requiredPermissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA  // Added for Blind Mode
        )

        // Check which permissions are missing
        val missingPermissions = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        // Request missing permissions if any
        if (missingPermissions.isNotEmpty()) {
            requestPermissionLauncher.launch(missingPermissions.toTypedArray())
        }

        setContent {
            MaterialTheme {
                AssistantApp(this)
            }
        }
    }
}
@Composable
fun AssistantApp(context: Context) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "main"
    ) {
        composable("main") { MainPage(navController) }
        composable("outdoorNavigation") { OutdoorNavigationScreen(context) }
        composable("blindMode") { BlindModeUI() } // Add this line
    }
}

@Composable
fun MainPage(navController: androidx.navigation.NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Outdoor Navigation Button
        Button(
            onClick = { navController.navigate("outdoorNavigation") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .semantics { contentDescription = "Outdoor Navigation" },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
        ) {
            Text("Outdoor Navigation", color = Color.White)
        }

        // Blind Mode Button
        Button(
            onClick = { navController.navigate("blindMode") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .semantics { contentDescription = "Blind Mode" },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Green)
        ) {
            Text("Blind Mode", color = Color.White)
        }
    }
}

@Composable
fun OutdoorNavigationScreen(context: Context) {
    var pickupLocation by remember { mutableStateOf("Fetching your location...") }
    var dropLocation by remember { mutableStateOf("Speak destination") }
    var routeInfo by remember { mutableStateOf("Press start navigation when ready") }
    var routeDetails by remember { mutableStateOf<List<String>>(emptyList()) }
    var isListening by remember { mutableStateOf(false) }
    var currentLocation by remember { mutableStateOf<Location?>(null) }
    var isNavigating by remember { mutableStateOf(false) }

    // Text-to-Speech
    val tts = remember {
        mutableStateOf<TextToSpeech?>(null)
    }

    LaunchedEffect(Unit) {
        tts.value = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.value?.language = Locale.getDefault()
                tts.value?.setSpeechRate(0.9f)
                tts.value?.speak("Fetching your location", TextToSpeech.QUEUE_FLUSH, null, null)
            }
        }
    }

    // Voice recognition
    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else {
            Toast.makeText(context, "Speech recognition not available", Toast.LENGTH_LONG).show()
            null
        }
    }

    fun readDirections(steps: List<String>) {
        steps.forEachIndexed { index, step ->
            tts.value?.speak(step,
                if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                null, null)
        }
        isNavigating = true
    }

    fun calculateRoute(destination: String) {
        currentLocation?.let { location ->
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val destinationCoords = Geocoder(context, Locale.getDefault())
                        .getFromLocationName(destination, 1)
                        ?.firstOrNull()
                        ?.let { Pair(it.latitude, it.longitude) }

                    destinationCoords?.let { (lat, lng) ->
                        val result = fetchRoute(
                            "${location.longitude},${location.latitude}",
                            "$lng,$lat"
                        )
                        withContext(Dispatchers.Main) {
                            routeInfo = result.first
                            routeDetails = result.second
                            tts.value?.speak("Route found. ${result.first}. Starting navigation",
                                TextToSpeech.QUEUE_FLUSH, null, null)
                            readDirections(result.second)
                        }
                    } ?: run {
                        withContext(Dispatchers.Main) {
                            tts.value?.speak("Could not find destination", TextToSpeech.QUEUE_FLUSH, null, null)
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        tts.value?.speak("Error calculating route", TextToSpeech.QUEUE_FLUSH, null, null)
                    }
                }
            }
        }
    }
    fun startVoiceRecognition() {
        tts.value?.speak("Listening for destination", TextToSpeech.QUEUE_FLUSH, null, null)

        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            tts.value?.speak("Microphone permission required", TextToSpeech.QUEUE_FLUSH, null, null)
            return
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                matches?.firstOrNull()?.let {
                    dropLocation = "Destination: $it"
                    tts.value?.speak("Destination set to $it. Calculating route",
                        TextToSpeech.QUEUE_FLUSH, null, null)
                    calculateRoute(it)
                }
                isListening = false
            }

            override fun onError(error: Int) {
                val errorMessage = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio error"
                    SpeechRecognizer.ERROR_CLIENT -> "Client error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "No microphone permission"
                    else -> "Didn't catch that"
                }
                tts.value?.speak(errorMessage, TextToSpeech.QUEUE_FLUSH, null, null)
                isListening = false
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })

        try {
            recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Say your destination")
            })
            isListening = true
        } catch (e: Exception) {
            tts.value?.speak("Error starting voice recognition", TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    // Location services
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }

    // Location callback
    var lastSpokenLocation by remember { mutableStateOf("") }
    var lastSpokenTime by remember { mutableStateOf(0L) }

    val locationCallback = remember {
        object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                currentLocation = locationResult.lastLocation
                currentLocation?.let { location ->
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val addresses = Geocoder(context, Locale.getDefault())
                                .getFromLocation(location.latitude, location.longitude, 1)

                            val newLocationText = addresses?.firstOrNull()?.getAddressLine(0)
                                ?: "${location.latitude}, ${location.longitude}"

                            val currentTime = System.currentTimeMillis()
                            val timeDifference = currentTime - lastSpokenTime

                            if (newLocationText != lastSpokenLocation && timeDifference > 5000) {
                                lastSpokenLocation = newLocationText
                                lastSpokenTime = currentTime

                                CoroutineScope(Dispatchers.Main).launch {
                                    tts.value?.speak("Your location is $newLocationText. Please say your destination",
                                        TextToSpeech.QUEUE_FLUSH, null, null)

                                    delay(10000) // This should now work without errors

                                    startVoiceRecognition()
                                }

                            }

                            pickupLocation = "Current location: $newLocationText"

                        } catch (e: Exception) {
                            val coordsText = "${location.latitude}, ${location.longitude}"
                            pickupLocation = "Current location: $coordsText"

                            val currentTime = System.currentTimeMillis()
                            if (coordsText != lastSpokenLocation && (currentTime - lastSpokenTime) > 5000) {
                                lastSpokenLocation = coordsText
                                lastSpokenTime = currentTime
                                withContext(Dispatchers.Main) {
                                    tts.value?.speak("Your coordinates are $coordsText",
                                        TextToSpeech.QUEUE_FLUSH, null, null)

                                    delay(10000) // Wait before starting voice input
                                    startVoiceRecognition()
                                }
                            }
                        }
                    }
                }
            }

        }
    }


    // Request location updates
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10000)
                .setWaitForAccurateLocation(true)
                .setMinUpdateIntervalMillis(5000)
                .build()

            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
        } else {
            tts.value?.speak("Location permission not granted", TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }








    // Clean up
    DisposableEffect(Unit) {
        onDispose {
            tts.value?.stop()
            tts.value?.shutdown()
            recognizer?.destroy()
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = pickupLocation,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(8.dp)
        )

        Button(
            onClick = { startVoiceRecognition() },
            enabled = !isListening,
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Set destination by voice" },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isListening) Color.Gray else Color.Green
            )
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Mic, contentDescription = "Microphone")
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isListening) "Listening..." else "Speak Destination")
            }
        }

        Text(
            text = dropLocation,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(8.dp)
        )

        Button(
            onClick = { calculateRoute(dropLocation.removePrefix("Destination: ")) },
            enabled = dropLocation.startsWith("Destination: ") && !isListening,
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Start navigation" },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isNavigating) Color.Red else Color.Blue
            )
        ) {
            Text(if (isNavigating) "Stop Navigation" else "Start Navigation")
        }

        if (routeDetails.isNotEmpty()) {
            Button(
                onClick = { readDirections(routeDetails) },
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { contentDescription = "Repeat directions" }
            ) {
                Text("Repeat Directions")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = routeInfo,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(8.dp)
        )

        LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
            items(routeDetails) { step ->
                Card(
                    modifier = Modifier.padding(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.LightGray)
                ) {
                    Text(
                        text = step,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}

fun fetchRoute(start: String, end: String): Pair<String, List<String>> {
    val apiKey = "5b3ce3597851110001cf624828f799c4e10a4908b87c9d480519a4b2"
    if (apiKey.isBlank()) {
        return Pair("Error: API key not configured", emptyList())
    }

    val url = "https://api.openrouteservice.org/v2/directions/driving-car?api_key=$apiKey&start=$start&end=$end"

    return try {
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return Pair("Error: ${response.code} - ${response.message}", emptyList())
            }

            val responseBody = response.body?.string() ?: ""
            parseRouteResponse(responseBody)
        }
    } catch (e: Exception) {
        Pair("Error: ${e.localizedMessage ?: "Unknown error"}", emptyList())
    }
}

fun parseRouteResponse(jsonResponse: String): Pair<String, List<String>> {
    return try {
        val jsonObject = JSONObject(jsonResponse)
        val features = jsonObject.getJSONArray("features")
        if (features.length() > 0) {
            val properties = features.getJSONObject(0).getJSONObject("properties")
            val summary = properties.getJSONObject("summary")
            val distance = summary.getDouble("distance") / 1000
            val duration = summary.getDouble("duration") / 60

            val steps = mutableListOf<String>()
            if (properties.has("segments")) {
                val segments = properties.getJSONArray("segments")
                for (i in 0 until segments.length()) {
                    val segment = segments.getJSONObject(i)
                    val segmentSteps = segment.getJSONArray("steps")
                    for (j in 0 until segmentSteps.length()) {
                        val step = segmentSteps.getJSONObject(j)
                        steps.add("${step.getString("instruction")} (${"%.2f".format(step.getDouble("distance") / 1000)} km)")
                    }
                }
            }

            Pair(
                "${"%.2f".format(distance)} km, ${"%.1f".format(duration)} min",
                if (steps.isNotEmpty()) steps else listOf("Turn-by-turn directions not available")
            )
        } else {
            Pair("No route found", emptyList())
        }
    } catch (e: Exception) {
        Pair("Error parsing route: ${e.localizedMessage}", emptyList())
    }
}