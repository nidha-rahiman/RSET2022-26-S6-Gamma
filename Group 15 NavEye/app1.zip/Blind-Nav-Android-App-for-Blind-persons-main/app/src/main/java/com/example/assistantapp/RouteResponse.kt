package com.example.assistantapp

data class RouteResponse(
    val routes: List<Route>
)

data class Route(
    val geometry: String
)
