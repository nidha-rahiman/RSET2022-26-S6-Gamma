package com.example.assistantapp

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.PolylineOptions
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class MainActivity : FragmentActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private val apiKey = "5b3ce3597851110001cf624828f799c4e10a4908b87c9d480519a4b2"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        val start = "8.681495,49.41461"
        val end = "8.687872,49.420318"
        fetchRoute(start, end)
    }

    private fun fetchRoute(start: String, end: String) {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openrouteservice.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(RouteService::class.java)
        service.getRoute(apiKey, start, end).enqueue(object : Callback<RouteResponse> {
            override fun onResponse(call: Call<RouteResponse>, response: Response<RouteResponse>) {
                response.body()?.routes?.firstOrNull()?.let { route ->
                    val decodedPath = PolylineDecoder.decode(route.geometry)
                    val polylineOptions = PolylineOptions().addAll(decodedPath)
                    mMap.addPolyline(polylineOptions)
                }
            }

            override fun onFailure(call: Call<RouteResponse>, t: Throwable) {
                t.printStackTrace()
            }
        })
    }
}
