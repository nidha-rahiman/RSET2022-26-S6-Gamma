import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/mcq_question.dart';

class QuizService {
  final String baseUrl = "http://192.168.251.172:8000";

  Future<List<McqQuestion>> fetchTodaysMcqs() async {
    final response = await http.get(Uri.parse("$baseUrl/get-todays-mcqs"));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final mcqsList = data['mcqs'] as List;
      return mcqsList.map((mcq) => McqQuestion.fromJson(mcq)).toList();
    } else {
      throw Exception('Failed to load questions: ${response.statusCode}');
    }
  }
}
