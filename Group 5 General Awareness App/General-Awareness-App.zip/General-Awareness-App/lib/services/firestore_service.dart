// ignore_for_file: avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  //  Create user stats on signup
  Future<void> createUserStats() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    await _firestore.collection('userStats').doc(uid).set({
      'last_quiz_date': null,
      'correct_answers': 0,
      'points': 0,
    });
  }

  //  Update quiz results
  Future<void> updateQuizStats(
      {required int correctAnswers,
      required int totalQuestions,
      required int quizPoints}) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    final int incorrectAnswers = totalQuestions - correctAnswers;
    final int pointsGained = (correctAnswers * 5) - (incorrectAnswers * 2);

    final docRef = _firestore.collection('userStats').doc(uid);
    print("Updating stats: $correctAnswers correct, $quizPoints points");

    await docRef.update({
      'last_quiz_date': FieldValue.serverTimestamp(),
      'correct_answers': FieldValue.increment(correctAnswers),
      'points': FieldValue.increment(pointsGained),
    });
  }

  //  Get user points
  Future<int> getUserPoints() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return 0;

    final doc = await _firestore.collection('user_stats').doc(uid).get();
    return doc.exists ? (doc.data()?['points'] ?? 0) : 0;
  }
}
