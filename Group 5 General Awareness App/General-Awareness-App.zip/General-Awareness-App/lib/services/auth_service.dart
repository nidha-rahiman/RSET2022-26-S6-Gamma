import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<String?> signUp(String email, String password, String name) async {
    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Send email verification
      await userCredential.user?.sendEmailVerification();

      // Create Firestore document for quiz stats
      await FirebaseFirestore.instance
          .collection('userStats')
          .doc(userCredential.user!.uid)
          .set({
        'email': email,
        'displayName': name,
        'points': 0,
        'correct_answers': 0,
        'last_quiz_date': null,
        'createdAt': FieldValue.serverTimestamp(),
      });

      return "Verification email sent. Please check your inbox.";
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        return "Email is already registered. Please log in.";
      } else if (e.code == 'weak-password') {
        return "Password should be at least 6 characters.";
      } else {
        return "Sign Up Error: ${e.message}";
      }
    } catch (e) {
      return "An unexpected error occurred.";
    }
  }

  // Log In with Email & Password
  Future<String?> logIn(String email, String password) async {
    if (email.isEmpty || password.isEmpty) {
      return "Email and password cannot be empty.";
    }

    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
          email: email, password: password);

      //  Ensure email is verified before login
      if (!userCredential.user!.emailVerified) {
        await _auth.signOut();
        return "Please verify your email before logging in.";
      }

      return null; // Successful login
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case 'user-not-found':
          return "No account found for this email.";
        case 'wrong-password':
          return "Incorrect password.";
        case 'invalid-credential':
          return "The email or password is incorrect.";
        case 'invalid-email':
          return "Invalid email format.";
        default:
          return "Login Error: ${e.message}";
      }
    }
  }

  //  Log Out
  Future<void> logOut() async {
    await _auth.signOut();
  }

  // Get Current User
  User? get currentUser => _auth.currentUser;
}
