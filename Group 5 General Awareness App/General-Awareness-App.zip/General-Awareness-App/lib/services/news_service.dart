import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/news_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; //  Add this

class ApiService {
  final String baseUrl = "http://192.168.251.172:8000";

  // Fetch today's summarized news
  Future<List<NewsArticle>> fetchNews() async {
    final response = await http.get(Uri.parse("$baseUrl/get-todays-summaries"));

    if (response.statusCode == 200) {
      final newsResponse = NewsResponse.fromJson(response.body);
      return newsResponse.summarizedNews;
    } else {
      throw Exception("Failed to load news");
    }
  }

  // Fetch translated news from /translate-all
  Future<List<NewsArticle>> fetchTranslatedNews() async {
    final response = await http.get(Uri.parse("$baseUrl/translate-all"));

    if (response.statusCode == 200) {
      final jsonData = json.decode(utf8.decode(response.body.runes.toList()));
      final List<dynamic> translatedNewsList = jsonData['translated_news'];

      return translatedNewsList
          .map((item) => NewsArticle(
                title: item['translated_title']['trans'] ?? '',
                url: item['url'] ?? '',
                summary: item['translated_summary']['trans'] ?? '',
              ))
          .toList();
    } else {
      throw Exception("Failed to translate news");
    }
  }

  //  Firestore method to get user quiz stats
  Future<DocumentSnapshot<Map<String, dynamic>>> getUserStats(
      String uid) async {
    return FirebaseFirestore.instance.collection('userStats').doc(uid).get();
  }
}
