// lib/services/quiz_restriction_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class QuizRestrictionService {
  static Future<bool> hasAttemptedQuizToday(String uid) async {
    final docRef = FirebaseFirestore.instance.collection('userStats').doc(uid);
    final snapshot = await docRef.get();

    if (!snapshot.exists || !snapshot.data()!.containsKey('last_quiz_date')) {
      return false; // No previous attempt
    }

    final timestamp = snapshot['last_quiz_date'] as Timestamp;
    final lastDate = timestamp.toDate();
    final now = DateTime.now();

    // Compare only the date portion
    return lastDate.year == now.year &&
        lastDate.month == now.month &&
        lastDate.day == now.day;
  }
}
