class McqQuestion {
  final String question;
  final List<String> choices;
  final String correctAnswer;
  final String timestamp;

  const McqQuestion({
    required this.question,
    required this.choices,
    required this.correctAnswer,
    required this.timestamp,
  });

  factory McqQuestion.fromJson(Map<String, dynamic> json) {
    return McqQuestion(
      question: json['question'] as String,
      choices: List<String>.from(json['choices']),
      correctAnswer: json['correct_answer'] as String,
      timestamp: json['timestamp'] as String,
    );
  }

  int get correctAnswerIndex => choices.indexOf(correctAnswer);
}
