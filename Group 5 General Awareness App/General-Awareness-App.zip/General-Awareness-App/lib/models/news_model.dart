import 'dart:convert';

class NewsResponse {
  final List<NewsArticle> summarizedNews;

  NewsResponse({required this.summarizedNews});

  factory NewsResponse.fromJson(String source) {
    final jsonData = json.decode(utf8.decode(source.runes.toList()));
    final List<dynamic> newsList = jsonData['summarized_news'];

    return NewsResponse(
      summarizedNews: newsList.map((e) => NewsArticle.fromMap(e)).toList(),
    );
  }
}

class NewsArticle {
  final String title;
  final String url;
  final String summary;

  NewsArticle({
    required this.title,
    required this.url,
    required this.summary,
  });

  factory NewsArticle.fromMap(Map<String, dynamic> map) {
    return NewsArticle(
      title: map['title'] ?? '',
      url: map['url'] ?? '',
      summary: map['summary'] ?? '',
    );
  }

  // Convert to JSON for easy conversion
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'url': url,
      'summary': summary,
    };
  }

  // Create a copy of this object with modified values (for translations)
  NewsArticle copyWith({String? title, String? summary}) {
    return NewsArticle(
      title: title ?? this.title,
      url: url,
      summary: summary ?? this.summary,
    );
  }
}
