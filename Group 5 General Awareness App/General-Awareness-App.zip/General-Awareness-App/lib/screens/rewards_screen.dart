// ignore_for_file: use_build_context_synchronously, curly_braces_in_flow_control_structures

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class RewardsScreen extends StatefulWidget {
  const RewardsScreen({super.key});

  @override
  State<RewardsScreen> createState() => _RewardsScreenState();
}

class _RewardsScreenState extends State<RewardsScreen> {
  int userPoints = 0;
  String? userId;

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  Future<void> fetchUserData() async {
    userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId != null) {
      final doc = await FirebaseFirestore.instance
          .collection('userStats')
          .doc(userId)
          .get();
      setState(() {
        userPoints = doc['points'] ?? 0;
      });
    }
  }

  Future<void> redeemReward(String title, int cost) async {
    if (userPoints >= cost && userId != null) {
      await FirebaseFirestore.instance
          .collection('userStats')
          .doc(userId)
          .update({
        'points': userPoints - cost,
      });

      setState(() {
        userPoints -= cost;
      });

      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Redeemed!'),
          content: Text('You have successfully redeemed "$title".'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'))
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Not enough points to redeem this item.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 20),
        const Text(
          'Redeem Centre',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        Text('Your Points: $userPoints',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
        const SizedBox(height: 20),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream:
                FirebaseFirestore.instance.collection('rewards').snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData)
                return const Center(child: CircularProgressIndicator());

              final rewards = snapshot.data!.docs;

              return ListView.builder(
                itemCount: rewards.length,
                itemBuilder: (context, index) {
                  final data = rewards[index].data() as Map<String, dynamic>;
                  final title = data['title'] ?? 'Reward';
                  final points = data['points required'] ?? 0;
                  final imageUrl = data['image_url'];

                  return Card(
                    margin:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: ListTile(
                      leading: imageUrl != null
                          ? Image.network(imageUrl,
                              height: 50, width: 50, fit: BoxFit.cover)
                          : const Icon(Icons.card_giftcard, size: 40),
                      title: Text(title),
                      subtitle: Text('$points points'),
                      trailing: ElevatedButton(
                        onPressed: () => redeemReward(title, points),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFDD835),
                        ),
                        child: const Text('Redeem',
                            style: TextStyle(color: Colors.black)),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
