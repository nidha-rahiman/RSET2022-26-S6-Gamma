// ignore_for_file: avoid_print

import 'package:flutter/material.dart';
import 'dart:async';
import '../models/mcq_question.dart';
import '../services/quiz_service.dart';
import '../services/firestore_service.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  // Services
  final QuizService _quizService = QuizService();
  final FirestoreService _firestoreService = FirestoreService();

  // Constants
  static const int _secondsPerQuestion = 20;

  // Timer
  late int _totalTimeSeconds;
  late int _remainingSeconds;
  int _questionTimePassed = 0;
  int _quizPoints = 0;
  late Timer _timer;

  // Quiz state
  int _currentQuestionIndex = 0;
  int? _selectedAnswerIndex;
  bool _answerChecked = false;
  int _correctAnswers = 0;
  bool _isLoading = true;
  String? _errorMessage;
  bool _isMovingToNextQuestion = false;

  // Questions data
  List<McqQuestion> _questions = [];

  @override
  void initState() {
    super.initState();
    _loadQuestions();
  }

  @override
  void dispose() {
    if (_timer.isActive) {
      _timer.cancel();
    }
    super.dispose();
  }

  Future<void> _loadQuestions() async {
    try {
      final questions = await _quizService.fetchTodaysMcqs();

      setState(() {
        _questions = questions;
        _isLoading = false;

        // Calculate total time based on number of questions
        _totalTimeSeconds = _questions.length * _secondsPerQuestion;
        _remainingSeconds = _totalTimeSeconds;
      });

      _startTimer();
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _startTimer() {
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(oneSec, (timer) {
      setState(() {
        if (_remainingSeconds > 0) {
          _remainingSeconds--;
          _questionTimePassed++;

          // If time for current question has elapsed
          if (_questionTimePassed >= _secondsPerQuestion && !_answerChecked) {
            _checkAnswer(null); // Auto-check with no selection
          }
        } else {
          timer.cancel();
          _showTimeUpDialog();
        }
      });
    });
  }

  void _checkAnswer(int? selectedIndex) {
    final currentQuestion = _questions[_currentQuestionIndex];

    setState(() {
      _answerChecked = true;
      _selectedAnswerIndex = selectedIndex;

      if (selectedIndex == null) {
        // Skipped: no change
      } else if (selectedIndex == currentQuestion.correctAnswerIndex) {
        _correctAnswers++;
        _quizPoints += 5;
      } else {
        _quizPoints -= 2;
      }
    });

    if (!_isMovingToNextQuestion) {
      _isMovingToNextQuestion = true;
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          _nextQuestion();
        }
      });
    }
  }

  String _formatTime(int seconds) {
    return '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';
  }

  void _showTimeUpDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text("Time's Up!"),
        content: Text("You scored $_correctAnswers/${_questions.length}"),
        actions: [
          TextButton(
            onPressed: () => Navigator.popUntil(ctx, (route) => route.isFirst),
            child: const Text("Finish"),
          ),
        ],
      ),
    );
  }

  void _nextQuestion() {
    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
        _selectedAnswerIndex = null;
        _answerChecked = false;
        _questionTimePassed = 0;
        _isMovingToNextQuestion = false;
      });
    } else {
      print("✅ Quiz complete. Showing results...");

      _showResults();
    }
  }

  void _showResults() {
    _timer.cancel();
    print("🏁 Reached _showResults, sending stats...");

    // Update Firestore with stats
    _firestoreService.updateQuizStats(
      correctAnswers: _correctAnswers,
      totalQuestions: _questions.length,
      quizPoints: _quizPoints,
    );

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text("Quiz Completed"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Score: $_correctAnswers/${_questions.length}",
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text(
              "Accuracy: ${(_correctAnswers / _questions.length * 100).toStringAsFixed(1)}%",
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.popUntil(ctx, (route) => route.isFirst),
            child: const Text("Done"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return _buildLoadingScreen();
    }

    if (_errorMessage != null) {
      return _buildErrorScreen();
    }

    if (_questions.isEmpty) {
      return _buildEmptyQuestionsScreen();
    }

    return _buildQuizScreen();
  }

  Widget _buildLoadingScreen() {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daily Quiz"),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: const Center(child: CircularProgressIndicator()),
    );
  }

  Widget _buildErrorScreen() {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daily Quiz"),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(_errorMessage!, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _isLoading = true;
                  _errorMessage = null;
                });
                _loadQuestions();
              },
              child: const Text("Retry"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyQuestionsScreen() {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daily Quiz"),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: const Center(
        child: Text("No questions available for today."),
      ),
    );
  }

  Widget _buildQuizScreen() {
    final currentQuestion = _questions[_currentQuestionIndex];
    final remainingQuestionTime = _secondsPerQuestion - _questionTimePassed;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Daily Quiz"),
        backgroundColor: Theme.of(context).primaryColor,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.secondary,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                const Icon(Icons.schedule, size: 16),
                const SizedBox(width: 4),
                Text(
                  _formatTime(_remainingSeconds),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Overall progress
            LinearProgressIndicator(
              value: (_currentQuestionIndex + 1) / _questions.length,
              backgroundColor: Colors.grey[200],
              valueColor:
                  AlwaysStoppedAnimation(Theme.of(context).primaryColor),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Question ${_currentQuestionIndex + 1}/${_questions.length}",
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Row(
                  children: [
                    Icon(
                      Icons.timer,
                      size: 16,
                      color: remainingQuestionTime < 5
                          ? Colors.red
                          : Colors.black54,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      "${remainingQuestionTime}s",
                      style: TextStyle(
                        color: remainingQuestionTime < 5
                            ? Colors.red
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              currentQuestion.question,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 30),
            Expanded(
              child: ListView.separated(
                itemCount: currentQuestion.choices.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (ctx, index) => _buildAnswerOption(
                  index: index,
                  option: currentQuestion.choices[index],
                  isSelected: _selectedAnswerIndex == index,
                  isCorrect: _answerChecked &&
                      index == currentQuestion.correctAnswerIndex,
                  isWrong: _answerChecked &&
                      (_selectedAnswerIndex == index &&
                          index != currentQuestion.correctAnswerIndex),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnswerOption({
    required int index,
    required String option,
    required bool isSelected,
    required bool isCorrect,
    required bool isWrong,
  }) {
    Color backgroundColor = Colors.white;
    if (isCorrect) {
      backgroundColor = Colors.green.shade100;
    } else if (isWrong) {
      backgroundColor = Colors.red.shade100;
    } else if (isSelected) {
      backgroundColor = Colors.blue.shade100;
    }

    return Card(
      color: backgroundColor,
      elevation: isSelected ? 3 : 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(
          color: isCorrect
              ? Colors.green
              : isWrong
                  ? Colors.red
                  : isSelected
                      ? Colors.blue
                      : Colors.grey.shade300,
          width: isSelected || isCorrect || isWrong ? 2 : 1,
        ),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: isCorrect
              ? Colors.green
              : isWrong
                  ? Colors.red
                  : Theme.of(context).colorScheme.secondary,
          child: Text(
            String.fromCharCode(65 + index), // A, B, C, D
            style: TextStyle(
              color: isCorrect || isWrong ? Colors.white : Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        title: Text(
          option,
          style: TextStyle(
            fontWeight:
                isSelected || isCorrect ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        onTap: () {
          if (!_answerChecked) {
            _checkAnswer(index);
          }
        },
      ),
    );
  }
}
