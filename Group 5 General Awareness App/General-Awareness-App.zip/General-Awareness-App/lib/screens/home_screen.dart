// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/news_service.dart';
import '../models/news_model.dart';
import 'profile_screen.dart';
import 'leaderboard_screen.dart';
import 'rewards_screen.dart';
import 'quiz_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // required for Timestamp

class HomeScreen extends StatefulWidget {
  final int initialIndex;

  const HomeScreen({
    super.key,
    this.initialIndex = 0,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late int _currentIndex;
  late Future<List<NewsArticle>> newsFuture;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _isTranslated = false; // Track translation state
  List<NewsArticle>? _newsCache;
  List<NewsArticle>? _translatedNewsCache;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _loadNews();
    _syncRouteWithIndex();
  }

  void _loadNews() {
    setState(() {
      newsFuture = _isTranslated ? _getTranslatedNews() : _getOriginalNews();
    });
  }

  Future<List<NewsArticle>> _getOriginalNews() async {
    _newsCache ??= await ApiService().fetchNews();
    return _newsCache!;
  }

  Future<List<NewsArticle>> _getTranslatedNews() async {
    _translatedNewsCache ??= await ApiService().fetchTranslatedNews();
    return _translatedNewsCache!;
  }

  void _syncRouteWithIndex() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final route = ModalRoute.of(context);
      if (route != null) {
        final settings = route.settings;
        if (settings.name == '/profile') {
          _currentIndex = 1;
        } else if (settings.name == '/quiz') {
          _currentIndex = 2;
        } else if (settings.name == '/leaderboard') {
          _currentIndex = 3;
        } else if (settings.name == '/rewards') {
          _currentIndex = 4;
        } else {
          _currentIndex = 0;
        }
      }
    });
  }

  Widget _getScreen() {
    switch (_currentIndex) {
      case 0:
        return _buildHomeContent();
      case 1:
        return const ProfileScreen();
      case 2:
        return const QuizScreen();
      case 3:
        return const LeaderboardScreen();
      case 4:
        return const RewardsScreen();
      default:
        return _buildHomeContent();
    }
  }

  Widget _buildHomeContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.all(16.0),
          child: Text(
            'News',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<NewsArticle>>(
            future: newsFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text("Error: ${snapshot.error}"));
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(child: Text("No news available"));
              }

              return ListView.builder(
                padding: const EdgeInsets.all(16.0),
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final news = snapshot.data![index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    child: ListTile(
                      title: Text(news.title,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(news.summary.isEmpty
                          ? "No summary available"
                          : news.summary),
                      onTap: () => _openNewsUrl(news.url),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawer: _buildDrawer(),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.black),
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: const Text(
          'Brevity',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          if (_currentIndex == 0)
            Padding(
              padding: const EdgeInsets.only(right: 16.0),
              child: ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    _isTranslated = !_isTranslated;
                    _loadNews();
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(_isTranslated
                          ? 'Translated to Malayalam'
                          : 'Switched to English'),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                },
                icon: const Icon(Icons.translate),
                label: Text(_isTranslated ? 'English' : 'മലയാളം'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  foregroundColor: Colors.black,
                ),
              ),
            ),
        ],
      ),
      body: _getScreen(),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Container(
        color: const Color(0xFF131B2F),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Color(0xFF131B2F)),
              child: Text(
                'Brevity',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
            _buildDrawerItem(Icons.home_outlined, 'HOME', 0, '/home'),
            _buildDrawerItem(Icons.person_outlined, 'PROFILE', 1, '/profile'),
            _buildDrawerItem(Icons.quiz_outlined, 'DAILY QUIZ', 2, '/quiz'),
            _buildDrawerItem(
                Icons.leaderboard_outlined, 'LEADERBOARD', 3, '/leaderboard'),
            _buildDrawerItem(
                Icons.card_giftcard_outlined, 'REDEEM CENTER', 4, '/rewards'),
            const Divider(color: Colors.grey),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.grey),
              title: const Text('LOGOUT', style: TextStyle(color: Colors.grey)),
              onTap: () async {
                try {
                  await FirebaseAuth.instance.signOut();
                  Navigator.pushNamedAndRemoveUntil(
                      context, '/', (route) => false);
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error signing out: $e')),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem(
      IconData icon, String text, int index, String routeName) {
    return ListTile(
      leading: Icon(icon,
          color: _currentIndex == index ? Colors.white : Colors.grey[400]),
      title: Text(
        text,
        style: TextStyle(
          color: _currentIndex == index ? Colors.white : Colors.grey[400],
        ),
      ),
      onTap: () async {
        Navigator.pop(context);

        if (routeName == '/quiz') {
          await _handleQuizAccess(); // Handles restriction and sets index
        } else {
          setState(() => _currentIndex = index); // Just switch screen
        }
      },
      selected: _currentIndex == index,
      // ignore: deprecated_member_use
      selectedTileColor: Colors.black.withOpacity(0.2),
    );
  }

  void _openNewsUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _handleQuizAccess() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final docSnapshot = await ApiService().getUserStats(user.uid);
    final now = DateTime.now();

    if (docSnapshot.exists) {
      final data = docSnapshot.data();
      final lastQuizDateTimestamp = data?['last_quiz_date'];

      if (lastQuizDateTimestamp != null) {
        final lastDate = (lastQuizDateTimestamp as Timestamp).toDate();

        if (now.year == lastDate.year &&
            now.month == lastDate.month &&
            now.day == lastDate.day) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("You have already taken today’s quiz."),
            ),
          );
          return; //  Stop quiz access
        }
      }
    }

    setState(() => _currentIndex = 2); // ✅ Load quiz inside HomeScreen
  }
}
