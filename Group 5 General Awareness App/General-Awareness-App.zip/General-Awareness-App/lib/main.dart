import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const BrevityApp());
}

class BrevityApp extends StatelessWidget {
  const BrevityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Brevity',
      theme: ThemeData(
        primaryColor: const Color(0xFF131B2F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF131B2F),
          primary: const Color(0xFF131B2F),
          secondary: const Color(0xFFFDD835),
        ),
        fontFamily: 'Poppins',
      ),
      debugShowCheckedModeBanner: false,
      home: AuthWrapper(), // Authentication Wrapper
      routes: {
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/home': (context) => const HomeScreen(initialIndex: 0),
        '/profile': (context) => const HomeScreen(initialIndex: 1),
        '/quiz': (context) => const HomeScreen(initialIndex: 2),
        '/leaderboard': (context) => const HomeScreen(initialIndex: 3),
        '/rewards': (context) => const HomeScreen(initialIndex: 4),
      },
    );
  }
}

// This widget determines whether to show login or home screen
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasData) {
          return const HomeScreen(initialIndex: 0); // User logged in
        }
        return const WelcomeScreen(); // User not logged in
      },
    );
  }
}
