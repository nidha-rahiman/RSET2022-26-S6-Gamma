package com.example.brevity_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
