// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter_test/flutter_test.dart';

// Change this import to match your actual project name from pubspec.yaml
import 'package:brevity_app/main.dart';

void main() {
  testWidgets('App launches and shows welcome screen', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const BrevityApp());

    // Verify that the welcome screen appears with correct text
    expect(find.text('Brevity'), findsOneWidget);
    expect(find.text('NEWS IN A BITE'), findsOneWidget);
    expect(find.text('SIGN UP'), findsOneWidget);
    expect(find.text('LOG IN'), findsOneWidget);
  });

  testWidgets('Navigation to signup screen works', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const BrevityApp());

    // Tap the signup button and trigger a frame.
    await tester.tap(find.text('SIGN UP'));
    await tester.pumpAndSettle();

    // Verify we're on the signup screen
    expect(find.text('First name'), findsOneWidget);
    expect(find.text('Last name'), findsOneWidget);
    expect(find.text('Email'), findsOneWidget);
    expect(find.text('Password'), findsOneWidget);
    expect(find.text('I agree to Terms & Conditions'), findsOneWidget);
  });
}