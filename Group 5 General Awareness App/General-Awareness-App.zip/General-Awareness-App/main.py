from fastapi import FastAPI
import requests
from newspaper import Article
from transformers import T5ForConditionalGeneration, T5Tokenizer
import nltk
import logging
import random
from transformers import pipeline
import google.generativeai as genai
import ast
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(" FastAPI is starting... Logging is working!")

try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    nltk.download("punkt")

# Initialize FastAPI
app = FastAPI()

# Load trained T5 model
MODEL_PATH = "trained_t5_model"
tokenizer = T5Tokenizer.from_pretrained(MODEL_PATH)
model = T5ForConditionalGeneration.from_pretrained(MODEL_PATH)

# Load NER model
ner_pipeline = pipeline("ner", model="dbmdz/bert-large-cased-finetuned-conll03-english", aggregation_strategy="simple")

# gemini API Key
genai.configure(api_key="AIzaSyBlP8bbDhmG7HG274jbL5dLdp6uzz4lu8k")

# Initialize the model
gemini_model = genai.GenerativeModel("gemini-1.5-flash")

# NewsAPI Key
API_KEY = "3e7f6106a0b94a30bab68c6931f4216b"

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Firestore setup
import firebase_admin
from firebase_admin import credentials, firestore

# Initialize Firebase
cred = credentials.Certificate("firebase_credentials.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

import hashlib
from datetime import datetime, timezone , timedelta

UNWANTED_KEYWORDS = [
    "advertisement", "subscription", "editorial", "perspectives", 
    "insights", "newsletter", "morning briefing", "premium"
]

def is_valid_article(title, description):
    """Returns True if the article is relevant news and not promotional content."""
    combined_text = f"{title} {description}".lower()
    return not any(keyword in combined_text for keyword in UNWANTED_KEYWORDS)


def store_summary(title, summary, url):
    """Stores summarized news in Firestore, using a hash of the title as the document ID."""
    # Create a unique document ID using a hash of the title
    doc_id = hashlib.sha256(title.encode()).hexdigest()
    
    db.collection("summarized_news").document(doc_id).set({
        "title": title,
        "summary": summary,
        "url": url,
        "timestamp": datetime.now(timezone.utc)  
    })
    logger.info(f"Stored in Firestore: {title}")


def summarize_text(text):
    """Summarizes the given news article text."""
    logger.info("Summarizing text")
    inputs = tokenizer("summarize: " + text, return_tensors="pt", max_length=512, truncation=True)
    summary_ids = model.generate(
        inputs["input_ids"],
        max_length=164,  
        min_length=50,  
        num_beams=5,  
        repetition_penalty=2.5,  
        no_repeat_ngram_size=3,  
        eos_token_id=tokenizer.eos_token_id,
        length_penalty=1.0,
        early_stopping=True
    )
    summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)
    logger.info(f"Summary: {summary}")
    return summary

def get_full_article(url):
    """Extracts and cleans full news article text, removing metadata and unwanted content."""
    try:
        article = Article(url)
        article.download()
        article.parse()
        
        # Check if article content is meaningful (at least 100 words)
        if len(article.text.split()) < 100:
            logger.warning(f"Skipping article: content too short ({len(article.text.split())} words)")
            return None 

        return article.text
    except Exception as e:
        logger.error(f"Error fetching article from {url}: {e}")
        return None  
    
def extract_key_answer_with_context(summary):
    """Extracts the most relevant answer(s) from the summary based on entity category."""
    entities = ner_pipeline(summary)
    categorized_entities = {"DATE": [], "PER": [], "ORG": [], "LOC": [], "MISC": []}
    best_answers, best_category, best_context = [], None, None

    # Categorize extracted entities
    for entity in entities:
        word = entity["word"].strip()
        category = entity["entity_group"]
        if category in categorized_entities:
            categorized_entities[category].append(word)

    # Prioritization Order: DATE > PERSON > ORG > LOC > MISC
    for category in ["DATE", "PER", "ORG", "LOC", "MISC"]:
        if categorized_entities[category]:
            if category == "PER":
                # Keep multiple names only if they appear in the same sentence
                sentence_candidates = [line for line in summary.split(".") if any(ans in line for ans in categorized_entities[category])]
                if sentence_candidates:
                    best_context = sentence_candidates[0]
                    best_answers = [name for name in categorized_entities[category] if name in best_context]
                else:
                    best_answers = [categorized_entities[category][0]]  # one name
            else:
                best_answers = [categorized_entities[category][0]]  # Always pick one answer for other categories
                best_context = next((line for line in summary.split(".") if best_answers[0] in line), summary)
            
            best_category = category
            break  

    return best_answers, best_category, best_context

def extract_all_possible_answers(summary):
    """Extracts all relevant entities that could be correct answers."""
    entities = ner_pipeline(summary)
    correct_answers = []

    # Extract all entity words
    for entity in entities:
        word = entity["word"].strip()
        correct_answers.append(word)

    return correct_answers

def normalize_choices(choices):
    """Ensures all choices are plain strings."""
    return [choice[0] if isinstance(choice, list) else choice for choice in choices]

def generate_mcq_with_gemini(summary):
    """Generates an MCQ using Gemini for question and distractors, ensuring factual and logical accuracy."""
    
    # Extract all possible correct answers
    possible_correct_answers = extract_all_possible_answers(summary)

    # Extract the best answer and context
    best_answer, answer_category, best_context = extract_key_answer_with_context(summary)
    if not best_answer:
        return {"error": "No valid answer could be extracted from the summary."}

    # Entity-Based Distractor Guidelines
    distractor_instructions = {
        "PERSON": """
        - Distractors should be **other real people** similar to the correct answer in **field or relevance**.
        - Example: If the correct answer is "Elon Musk", distractors could be "Jeff Bezos", "Bill Gates", or "Mark Zuckerberg".
        """,
        "LOCATION": """
        - Distractors should be **similar locations** such as cities, countries, or landmarks.
        - Example: If the correct answer is "Paris", distractors could be "London", "Berlin", or "Rome".
        """,
        "ORG": """
        - Distractors should be **other organizations in the same industry or field**.
        - Example: If the correct answer is "Google", distractors could be "Microsoft", "Amazon", or "Apple".
        """,
        "DATE": """
        - Distractors should be **historically significant but incorrect** dates.
        - Example: If the correct answer is "July 4, 1776", distractors could be "July 14, 1789", "September 17, 1787", or "June 18, 1815".
        """,
        "NUM": """
        - Distractors should be **similar numerical values** that are plausible but incorrect.
        - Example: If the correct answer is "100", distractors could be "95", "110", or "120".
        """,
        "MISC": """
        - Distractors should be **logically plausible but factually incorrect alternatives**.
        - Example: If the correct answer is "COVID-19", distractors could be "SARS", "Ebola", or "Zika Virus".
        """
    }

    # instruction set 
    entity_guidelines = distractor_instructions.get(answer_category, distractor_instructions["MISC"])

    # Prompt for Gemini
    prompt = f"""
    Based on the following news summary, generate a multiple-choice question.

    **News Summary:**  
    {summary[:500]}  

    **Correct Answer:**  
    "{best_answer}"  

    **Entity Type:** {answer_category}  

    **Distractor Guidelines:**  
    {entity_guidelines}  

    **Exclude These Possible Correct Answers from Distractors:**  
    {possible_correct_answers}  

    **Output Format (STRICTLY FOLLOW THIS JSON FORMAT):**  
    ```json
    {{
        "question": "Generated question here",
        "distractors": ["Choice A", "Choice B", "Choice C"]
    }}
    ```

    **Rules:**  
    - The question must be factually accurate and directly related to the correct answer.  
    - Distractors must be **logically relevant** but **incorrect**.  
    - Avoid using **any possible correct answers** as distractors.  
    - Keep the question **clear and unambiguous**.  
    """

    # Call Gemini API
    try:
        response = gemini_model.generate_content(prompt)

        # Verify response
        if not response or not hasattr(response, "text"):
            print("No valid response from Gemini.")
            return {"error": "No response received from Gemini."}

        raw_text = response.text.strip()
        print("Gemini Raw Response:", raw_text)

        # Clean and parse response
        if raw_text.startswith("```json") and raw_text.endswith("```"):
            raw_text = raw_text[7:-3].strip()

        if raw_text.startswith("{") and raw_text.endswith("}"):
            mcq_data = ast.literal_eval(raw_text)
        else:
            print("Unexpected response format:", raw_text)
            return {"error": "Gemini response format invalid."}

        # Normalize choices
        distractors = normalize_choices(mcq_data["distractors"])
        correct_answer = normalize_choices([best_answer])[0]

        if correct_answer in distractors:
            distractors.remove(correct_answer)  # Remove correct answer from distractors

        choices = distractors + [correct_answer]
        random.shuffle(choices)

        return {
            "question": mcq_data["question"],
            "choices": choices,
            "correct_answer": correct_answer
        }

    except Exception as e:
        print("Error generating MCQ with Gemini:", e)
        return {"error": "Failed to generate MCQ using Gemini."}


@app.get("/fetch-todays-summaries")
def fetch_and_store_daily_news():
    """Fetches news articles, extracts full content, and summarizes them."""
    
    # Fetch latest news
    URL = f"https://newsapi.org/v2/top-headlines?country=us&apiKey={API_KEY}"
    response = requests.get(URL)
    
    # Handle API errors
    if response.status_code != 200:
        logger.error(f"NewsAPI request failed with status code: {response.status_code}")
        return {"error": "NewsAPI request failed", "status": response.status_code}

    news_data = response.json()
    #logger.info(f"NewsAPI response: {news_data}")

    if "articles" not in news_data or not news_data["articles"]:
        logger.error("No articles found in the NewsAPI response")
        return {"error": "No articles found"}

    summarized_articles = []

    for article in news_data["articles"][:10]:  
        title = article["title"]
        description = article.get("description", "")
        news_url = article["url"]

        if not is_valid_article(title, description):
            logger.info(f"Skipping promotional article: {title}")
            continue

        full_content = get_full_article(news_url)  
        if not full_content:
            continue  # Skip articles with no valid content

        summary = summarize_text(full_content)  
        store_summary(title, summary, news_url)  
        summarized_articles.append({"title": title, "summary": summary, "url": news_url})


    print("Daily news summarized and stored in firestore")

from fastapi.responses import JSONResponse
import json

@app.get("/get-todays-summaries")
def get_todays_summaries():
    """Fetch only today's summarized news from Firestore."""
    
    # Get today's date in UTC
    now = datetime.now(timezone.utc)
    start_of_day = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
    end_of_day = start_of_day + timedelta(days=1)

    summaries_ref = db.collection("summarized_news") \
                      .where("timestamp", ">=", start_of_day) \
                      .where("timestamp", "<", end_of_day) \
                      .order_by("timestamp", direction=firestore.Query.DESCENDING)
    
    docs = summaries_ref.stream()

    summarized_news = []
    for doc in docs:
        news_item = doc.to_dict()
        summarized_news.append(news_item)

    return JSONResponse(
    content={
        "summarized_news": [
            {key: value for key, value in item.items() if key != "timestamp"}
            for item in summarized_news
        ]
    },
    media_type="application/json"
)


#translation  using google translate from rapid api
RAPIDAPI_KEY = "f7a21608acmshea163def8f454a1p1a9b04jsnf11d2c500a9e"
RAPIDAPI_HOST = "google-translate113.p.rapidapi.com"

def translate_text(text: str, source: str = "en", target: str = "ml") -> str:
    if not text:
        logger.error("Translation text is empty.")
        return "Translation error: Empty text"
    """ Calls RapidAPI Google Translate and returns translated text """
    url = "https://google-translate113.p.rapidapi.com/api/v1/translator/text"
    
    headers = {
        "x-rapidapi-key": RAPIDAPI_KEY,
        "x-rapidapi-host": RAPIDAPI_HOST,
        "Content-Type": "application/json"
    }
    
    payload = {
        "from": source,
        "to": target,
        "text": text
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        return response.json()
    else:
        logger.error(f"Translation API failed: {response.text}")
        return "Translation error"
    
@app.get("/translate-all")
def translate_all_summaries():
    now = datetime.now(timezone.utc)
    start_of_day = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
    end_of_day = start_of_day + timedelta(days=1)

    summaries_ref = db.collection("summarized_news") \
                      .where("timestamp", ">=", start_of_day) \
                      .where("timestamp", "<", end_of_day) \
                      .order_by("timestamp", direction=firestore.Query.DESCENDING)
    
    docs = summaries_ref.stream()

    translated_summaries = []
    
    for doc in docs:
        news_item = doc.to_dict()
        translated_title = translate_text(news_item["title"])
        translated_text = translate_text(news_item["summary"])
        translated_summaries.append({
            "english_title": news_item["title"],
            "translated_title": translated_title,
            "english_summary": news_item["summary"],
            "translated_summary": translated_text,
            "url": news_item["url"]
        })

    return {"translated_news": translated_summaries}

@app.get("/generate-todays-mcqs")
def generate_todays_mcqs():
    """Generates and stores MCQs for today's summarized news."""
    now = datetime.now(timezone.utc)
    start_of_day = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
    end_of_day = start_of_day + timedelta(days=1)

    summaries_ref = db.collection("summarized_news") \
                      .where("timestamp", ">=", start_of_day) \
                      .where("timestamp", "<", end_of_day) \
                      .order_by("timestamp", direction=firestore.Query.DESCENDING)

    docs = summaries_ref.stream()

    generated_mcqs = []

    for doc in docs:
        news_item = doc.to_dict()
        summary = news_item["summary"]

        mcq = generate_mcq_with_gemini(summary)

        if "error" in mcq:
            continue  # Skip problematic MCQs

        # Store MCQ in Firestore
        doc_id = hashlib.sha256(summary.encode()).hexdigest()
        db.collection("generated_mcqs").document(doc_id).set({
            "question": mcq["question"],
            "choices": mcq["choices"],
            "correct_answer": mcq["correct_answer"],
            "timestamp": datetime.now(timezone.utc)
        })

        generated_mcqs.append(mcq)

    return {"mcqs_generated": len(generated_mcqs)}


@app.get("/get-todays-mcqs")
def get_todays_mcqs():
    """Retrieve today's MCQs from Firestore."""
    now = datetime.now(timezone.utc)
    start_of_day = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
    end_of_day = start_of_day + timedelta(days=1)

    mcqs_ref =  db.collection("generated_mcqs") \
               .where("timestamp", ">=", start_of_day) \
               .where("timestamp", "<", end_of_day) \
               .order_by("timestamp", direction=firestore.Query.DESCENDING)

    docs = mcqs_ref.stream()
    mcq_list = [doc.to_dict() for doc in docs]

    return {"mcqs": mcq_list}